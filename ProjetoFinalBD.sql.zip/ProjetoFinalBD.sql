CREATE DATABASE LOJA;

CREATE TABLE marca (
    cod_marca SERIAL PRIMARY KEY,
    nome_marca VARCHAR(100) NOT NULL
);

SELECT * FROM marca

CREATE TABLE produto (
    cod_prod SERIAL PRIMARY KEY,
    nome_produto VARCHAR(100) NOT NULL,
    cod_marca INTEGER NOT NULL REFERENCES marca(cod_marca),
    preco NUMERIC(10, 2) NOT NULL
);

SELECT *FROM produto

CREATE TABLE estoque (
    cod_estoque SERIAL PRIMARY KEY,
    cod_prod INTEGER NOT NULL REFERENCES produto(cod_prod),
    qtd_est INTEGER NOT NULL
);

SELECT *FROM estoque

